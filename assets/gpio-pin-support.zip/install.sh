#!/bin/bash

# This script sets up I2C device access permissions for the current user

USER_TO_ADD=${1:-$USER}  # Use first argument or current user

sudo apt update && sudo apt install i2c-tools

echo "[INFO] Detecting I2C bus..."
i2cdetect -y 1

echo "[INFO] Checking /dev/i2c-1..."
ls -l /dev/i2c-1

echo "[INFO] Creating 'i2c' group if it doesn't exist..."
sudo groupadd -f i2c

echo "[INFO] Changing group of /dev/i2c-1 to 'i2c'..."
sudo chown :i2c /dev/i2c-1

echo "[INFO] Giving group 'i2c' read/write permissions..."
sudo chmod g+rw /dev/i2c-1

echo "[INFO] Adding user '$USER_TO_ADD' to 'i2c' group..."
sudo usermod -aG i2c "$USER_TO_ADD"

echo "[INFO] Adding udev rule to persist permissions..."
echo 'KERNEL=="i2c-[0-9]*", GROUP="i2c", MODE="0660"' | sudo tee /etc/udev/rules.d/10-local_i2c_group.rules > /dev/null

echo "[INFO] Reloading udev rules..."
sudo udevadm control --reload-rules
sudo udevadm trigger

echo "[INFO] Done. Please reboot or log out and back in for group changes to take effect."

